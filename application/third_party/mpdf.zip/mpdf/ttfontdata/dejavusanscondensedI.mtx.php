<?php
$name='DejaVuSansCondensed-Oblique';
$type='TTF';
$desc=array (
  'Ascent' => 928.0,
  'Descent' => -236.0,
  'CapHeight' => 928.0,
  'Flags' => 68,
  'FontBBox' => '[-914 -350 1493 1068]',
  'ItalicAngle' => -11.0,
  'StemV' => 87.0,
  'MissingWidth' => 540.0,
);
$up=-63;
$ut=44;
$ttffile='/home/homeofbulldogs/public_html/dev/selectinc/application/third_party/mpdf/ttfonts/DejaVuSansCondensed-Oblique.ttf';
$TTCfontID='0';
$originalsize=489032;
$sip=false;
$smp=false;
$BMPselected=true;
$fontkey='dejavusanscondensedI';
$panose=' 0 0 2 b 6 6 3 3 4 b 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>