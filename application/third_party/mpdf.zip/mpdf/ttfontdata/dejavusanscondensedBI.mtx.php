<?php
$name='DejaVuSansCondensed-BoldOblique';
$type='TTF';
$desc=array (
  'Ascent' => 928.0,
  'Descent' => -236.0,
  'CapHeight' => 928.0,
  'Flags' => 262212,
  'FontBBox' => '[-960 -385 1799 1121]',
  'ItalicAngle' => -11.0,
  'StemV' => 165.0,
  'MissingWidth' => 540.0,
);
$up=-63;
$ut=44;
$ttffile='/home/homeofbulldogs/public_html/dev/selectinc/application/third_party/mpdf/ttfonts/DejaVuSansCondensed-BoldOblique.ttf';
$TTCfontID='0';
$originalsize=493756;
$sip=false;
$smp=false;
$BMPselected=true;
$fontkey='dejavusanscondensedBI';
$panose=' 0 0 2 b 8 6 3 3 4 b 2 4';
$haskerninfo=false;
$unAGlyphs=false;
?>